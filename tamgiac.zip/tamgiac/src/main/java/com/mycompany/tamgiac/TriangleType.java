
package com.mycompany.tamgiac;

import java.util.Scanner;

public class TriangleType {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the length of the first side: ");
        int a = scanner.nextInt();

        System.out.print("Enter the length of the second side: ");
        int b = scanner.nextInt();

        System.out.print("Enter the length of the third side: ");
        int c = scanner.nextInt();

        String result = triangleType(a, b, c);
        System.out.println("Triangle type: " + result);
        
        scanner.close();
    }

    public static String triangleType(int a, int b, int c) {
        if (a <= 0 || b <= 0 || c <= 0) {
            return "NotATriangle";
        } else if (a == b && b == c) {
            return "Equilateral";
        } else if (a == b || b == c || c == a) {
            if (a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a) {
                return "Right";
            }
            return "Isosceles";
        } else if (a != b && b != c && c != a) {
            return "Scalene";
        } else {
            return "NotATriangle";
        }
    }
}

